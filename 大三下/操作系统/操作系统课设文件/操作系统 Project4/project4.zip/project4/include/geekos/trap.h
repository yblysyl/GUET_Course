/*
 * Trap handlers
 * Copyright (c) 2001, David H. Hovemeyer <daveho@cs.umd.edu>
 * $Revision: 1.7 $
 * 
 * This is free software.  You are permitted to use,
 * redistribute, and modify it as specified in the file "COPYING".
 */

#ifndef GEEKOS_TRAP_H
#define GEEKOS_TRAP_H

void Init_Traps(void);

#endif  /* GEEKOS_TRAP_H */
